/**
 * Contains stories for Podam annotations.
 *
 * Created by tedonema on 31/05/2015.
 *
 * @since 5.5.0
 */
package uk.co.jemos.podam.test.unit.features.annotations;