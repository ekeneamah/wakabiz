/**
 * Contains stories for Podam's handling of collections
 * Created by tedonema on 31/05/2015.
 */
package uk.co.jemos.podam.test.unit.features.collections;