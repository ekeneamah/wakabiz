/**
 * Contains stories for randomness validation.
 *
 * Created by daivanov on 05/02/2017.
 *
 * @since 7.0.5
 */
package uk.co.jemos.podam.test.unit.features.randomness;
