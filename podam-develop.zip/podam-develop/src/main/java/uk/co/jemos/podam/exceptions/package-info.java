/**
 * This package contains PODAM exceptions.
 */
package uk.co.jemos.podam.exceptions;

